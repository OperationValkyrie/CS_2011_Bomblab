Jonathan Chang
CS 2011 B05
Bomblab

This projects considers of a 'bomb' that the student must disarm by entering the correct passcodes. This is done by using gdb and comparing machine code to the expected input.

FOr more information, view the included pdf.